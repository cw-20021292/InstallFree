/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "water_level.h"



void input_water_level(void);
void input_room_water_level(void);
void input_overflow(void);


U8 u8_room_full_level_on_decision_cnt;
U8 u8_room_full_level_off_decision_cnt;

U8 gu8_Room_Water_Level;


U8 u8_overflow_on_decision_cnt;
U8 u8_overflow_off_decision_cnt;

bit bit_overflow_level;


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void input_water_level(void)
{
    /*..hui [19-6-26���� 1:12:15] ������ũ �������� �Է�..*/
    input_room_water_level();

    /*..hui [19-12-18���� 9:30:18] ����ħ ���� �߰�..*/
    input_overflow();

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void input_room_water_level(void)
{
    if( pLEVEL_HIGH == CLEAR )
    {
        u8_room_full_level_on_decision_cnt = 0;
        u8_room_full_level_off_decision_cnt++;

        if( u8_room_full_level_off_decision_cnt >= ROOM_WATER_LEVEL_DETECT_TIME )
        {
            u8_room_full_level_off_decision_cnt = ROOM_WATER_LEVEL_DETECT_TIME;
            gu8_Room_Water_Level = ROOM_LEVEL_LOW;
        }
        else{}
    }
    else
    {
        u8_room_full_level_off_decision_cnt = 0;
        u8_room_full_level_on_decision_cnt++;

        if( u8_room_full_level_on_decision_cnt >= ROOM_WATER_LEVEL_DETECT_TIME )
        {
            u8_room_full_level_on_decision_cnt = ROOM_WATER_LEVEL_DETECT_TIME;
            gu8_Room_Water_Level = ROOM_LEVEL_FULL;
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void input_overflow(void)
{
    if(pLEVEL_OVERFLOW == CLEAR)
    {
        u8_overflow_on_decision_cnt = 0;
        u8_overflow_off_decision_cnt++;

        if( u8_overflow_off_decision_cnt >= OVERFLOW_LEVEL_DETECT_TIME )
        {
            u8_overflow_off_decision_cnt = OVERFLOW_LEVEL_DETECT_TIME;

            /*..hui [20-9-25���� 5:23:40] ����ħ �ѹ� �����Ǹ� �����ǰ� ������ �̸��϶����� ��ٷȴ� ����..*/
            /*..hui [20-9-25���� 5:23:49] ��� �ѹ� �� Ȯ�� �ʿ� ��~~~~~~~~~..*/
            #if 0
            if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
            {
                bit_overflow_level = CLEAR;
            }
            else{}
            #endif

            bit_overflow_level = CLEAR;
        }
        else{}
    }
    else
    {
        u8_overflow_off_decision_cnt = 0;
        u8_overflow_on_decision_cnt++;

        if ( u8_overflow_on_decision_cnt >= OVERFLOW_LEVEL_DETECT_TIME )
        {
            u8_overflow_on_decision_cnt = OVERFLOW_LEVEL_DETECT_TIME;
            bit_overflow_level = SET;
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/



